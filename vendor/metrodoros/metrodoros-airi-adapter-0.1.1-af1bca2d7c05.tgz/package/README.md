# Metrodoros AIRI adapter

設計08に対応する、Metrodoros側の接続パッケージ。AIRI本体は変更しない。記憶の検索・人格・忘却閉包はサーバーを正本とし、このパッケージは会話単位の投影、ID対応、永続outbox、送信前検査、配信報告を担当する。

## 保存と接続

ブラウザーでは`IndexedDbStorage`、Node/Electronのmain側では`@metrodoros/airi-adapter/desktop`の`FileStorage`を使う。後者はNode.js 24のSQLiteを使い、別プロセス間でも採番とイベント挿入をトランザクションにする。正本サービスのDBとは別のファイルを指定する。`MemoryStorage`は試験用。

```ts
import {
  IndexedDbStorage,
  MemoryBridge,
  TokenHolder,
  createMetrodorosApi,
  parseSettings,
} from '@metrodoros/airi-adapter'

// hostは実装・検証済みのHostPorts。接続tokenは入力後のメモリ内だけに保持する。
const token = new TokenHolder(tokenInput)
const settings = parseSettings(savedSettings)
const storage = new IndexedDbStorage(installationClientNamespace)
const api = createMetrodorosApi({ endpoint: settings.endpoint, token: token.reveal() })
const bridge = new MemoryBridge({ storage, api, host, settings, instanceId: windowInstanceId })
await bridge.start()
await bridge.selectCard(cardId, { airiSessionId })
```

ストレージのnamespaceはインストール・認証clientごとに分ける。tokenをnamespace、カード、outbox、exportへ書かない。endpoint/tokenを変更する場合は旧bridgeを`disable()`し、新しいAPI/bridgeを組み立てる。既存の送信待ちを新しいアカウントへ流用しない。

起動・再接続は通知同期→ローカル無効化・停止→ACK→期限内outbox再送の順。共有storageを継承できるleader切替だけ`inheritLeader:true`を使う。独立したwindowは別session/writerになり、旧ownerの書き込みは拒否される。

## 実Conversationとproviderの境界

`prepareRequestContext`へ渡すのは`{ turns: [...] }`形式の実Conversation。`composedMessage`は表示用であり、この接続口には使わない。

```ts
const prepared = await bridge.prepareRequestContext({
  airiSessionId,
  userMessageId,
  attemptId,
  conversation,
  inputKind: 'typed',
  modelKey,
  signal,
})
if (prepared.mode === 'blocked') {
  showStatus(await bridge.status())
  return
}
if (prepared.mode === 'disabled') {
  // この結果には、過去に記憶連携した会話の履歴除外も反映される。
  return host.sendOrdinaryConversation(prepared.conversation)
}
const gate = await bridge.beforeProviderRequest(prepared.turn, 'initial')
if (!gate.allow) return
return host.sendConversation(prepared.conversation, { signal: prepared.turn.signal })
```

記憶付き/縮退時の出力は`ProviderConversation`。AIRIのsystem authority、segment配列、round/toolInvocations形式へ適合する型を公開する。上位のアプリ指示を残し、人格はdeveloper、記憶はcontextの引用データとして今回だけ組み立てる。保存履歴、原本、永続registryへ注入ブロックを書かない。

ツール往復・provider内部の互換再試行も、その実送信直前に同じturnへ`beforeProviderRequest(turn, 'continuation' | 'retry')`を適用する。初回の登録期限、継続時のサーバー検査、ローカル通知世代を検査し、拒否後に別の経路へ再送しない。返されたhandleは生成試行の実体へ結び付くため、古いhandleやコピーを新しい試行へ流用できない。

ホストが実送信ゲート、continuation除外、音声queue停止、通知同期を保証できない場合は有効化しない。未改造の手元AIRIは必要な汎用portがないため、この条件を満たしていると宣言してはならない。

## 配信hook

`prepared.turn.delivery`の呼び出しを、実際に観測したイベントへ結び付ける。

| 観測                              | 呼び出し                                                            |
| --------------------------------- | ------------------------------------------------------------------- |
| 実TTS要求の確定文                 | `ttsRequest({intentId, streamId, segmentId}, request.text)`         |
| 合成完了                          | `ttsResult(key, elapsedMs)`。配信済みにはしない                     |
| 実再生開始／正常終了              | `playbackStart(key)`／`playbackEnd(key)`                            |
| 中断／再生拒否                    | `playbackInterrupt(key)`／`playbackFail(key)`                       |
| LLM生成終端                       | `llmFinished(outcome, fullText, assistantMessageId)`                |
| このturnの全TTS要求を列挙し終えた | `speechRequestsComplete()`                                          |
| 最終本文の描画確認                | `displayed()`。描画不能なら`displayUnavailable()`                   |
| intentの終端／queue取消           | `intentEnd(intentId)`／`intentInterrupted(intentId)`                |
| 音声経路が終端・使用不可          | `audioUnavailable(reason)`。残りqueueを止めた後に呼ぶ               |
| 例外・ユーザー取消                | `bridge.cancelTurn(turn)`。生成済み部分は先に`recordProgress(text)` |

LLM終端後にTTS要求が来る場合も、列挙完了までfinalのchunk ID集合を確定しない。`intentEnd`だけで各チャンクの正常再生を推測しない。表示または全文の音声配信がACKされるまでは、生成文を次回のclient履歴へ入れない。Irodoriの文章分割や音量設定は変更しない。

1出力の詳細な配信記録は120チャンクまで。超えた場合は音声配信をunknownとして扱い、TTS自体の設定は変更しない。該当intentの終端を待つ。完了を捏造したり、manifestを切り捨てて配信済みとしない。

hook後の`await turn.flushLocalWrites()`はネットワーク送信を待たず、ローカルoutboxへの保存だけを確認する。ホストの停止・通知同期ではこちらを使い、outbox再送による待ちを発生させない。互換用の`await turn.flushWrites()`はローカル保存に加え、既に開始したoutbox送信の完了も待つ。ネットワークACKと保存状態は`bridge.status()`で確認し、出力の終端通知もoutboxで再送する。

## 通知・設定・人格移行

通知channelの切断は`await bridge.notificationDisconnected()`へ渡す。再接続は`syncNotifications()`。忘却・権限・barrier通知は保守的にローカル文脈を全リセットし、未ACK本文も消去する。停止が確認できない場合はACKしない。

`defaultSettings`/`parseSettings`/`serializeSettings`、`TokenHolder`、`describeStatus`、`Diagnostics`を設定UI向けに公開する。状態文言は「接続済み」「記憶を使わず会話」「整理待ち」「同期が必要」「保存できていない」。通常の診断exportは本文・tokenを含まない。

`PersonaMigration.propose(card)`は人格候補の表示まで。本人が見たdigestと`approvedByUser:true`を指定して`approve`したときだけ登録callbackを呼ぶ。ツール権限や実行規則を人格へ混ぜない。

モデル対応版の追加フィールドは、`GET /v1/airi/capabilities`で確認後に送る。[サーバー追加契約](../../docs/implementation/08-airi-adapter-contract.md)を参照。

## 検証範囲

Metrodorosの実HTTP/SDK/SQLite workerを使う結合、独立host fixture、ブラウザーIndexedDB、別プロセスのdesktop storageを検証する。AIRI側のport実装、設定画面への配置、実LLM/Irodoriを通した運転はAIRI本体へ組み込む段階の作業。本パッケージの試験成功を、その実接続の成功として表示しない。
